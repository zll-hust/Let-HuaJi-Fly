# Java group work for HUST Java programming class

## Contributors

- [周航](https://github.com/zll-hust)
- [向柯玮](https://github.com/huster-xkw)
- [李璠](https://github.com/lemon-ux)

## Advantages

- no advantages

## Requirements

- environment for jdk 1.8